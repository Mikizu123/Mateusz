require(["esri/WebMap", "esri/Map", "esri/views/MapView"], function(WebMap, Map, MapView, webMercatorUtils){
    let topo = document.getElementById("topo");
    let sat = document.getElementById("sat");
    let OSM = document.getElementById("OSM");
    let agol = document.getElementById("agol")

    let webmap = new WebMap({portalItem: {id: "d4e1e0a2d6824ea5a226082ec26aaecf"}});
    let map1 = new Map({basemap:'topo'}); 
    let map2 = new Map({basemap:'satellite'});
    let map3 = new Map({basemap:'osm'});

    let mapContainer = new MapView({
        container: "itemMap", 
        map: map1
    });

    topo.addEventListener("click",function(){
        mapContainer.map = map1;
    });

    sat.addEventListener("click",function(){
        mapContainer.map = map2;
    });

    OSM.addEventListener("click",function(){
        mapContainer.map = map3;
    });

    agol.addEventListener("click", function(){
        mapContainer.map = webmap;
    });

})

// require(["esri/Map", "esri/views/MapView", "esri/widgets/BasemapToggle", "esri/widgets/BasemapGallery", "esri/layers/GraphicsLayer", "esri/widgets/Sketch", "esri/layers/FeatureLayer"], 
// function(Map, MapView, BasemapToggle, BasemapGallery, GraphicsLayer, Sketch, FeatureLayer) {

//     var GraphicsLayer = new GraphicsLayer();

//     var map = new Map({
//       basemap: "topo-vector",
//       layers: [GraphicsLayer]
//     });

//     var view = new MapView({
//       container: "itemMap",
//       map: map,
//       center: [-118.80500,34.02700],
//       zoom: 13
//     });

//     var BasemapToggle= new BasemapToggle({
//         view: view,
//         nextBasemap: "satellite"
//     });
//         view.ui.add(BasemapToggle, "bottom-right");


//     var BasemapGallery = new BasemapGallery({
//         view: view,
//         source: {
//           portal: {
//             url: "https://www.arcgis.com",
//             useVectorBasemaps: true 
//           }
//         }
//       });
//         view.ui.add(BasemapGallery, "top-right");

//     var Sketch = new Sketch({
//         view: view,
//         layer: GraphicsLayer
//       });
//       view.ui.add(Sketch, "top-right");  

//       var trailheadsLayer = new FeatureLayer({
//         url: "https://services3.arcgis.com/GVgbJbqm8hXASVYi/arcgis/rest/services/Trailheads/FeatureServer/0"
//       });
//       map.add(trailheadsLayer);
      
//       var trailsLayer = new FeatureLayer({
//         url: "https://services3.arcgis.com/GVgbJbqm8hXASVYi/arcgis/rest/services/Trails/FeatureServer/0"
//       });
//       map.add(trailsLayer, 0);

//       var parksLayer = new FeatureLayer({
//         url: "https://services3.arcgis.com/GVgbJbqm8hXASVYi/arcgis/rest/services/Parks_and_Open_Space/FeatureServer/0"
//       });
//       map.add(parksLayer, 0);

//   });

